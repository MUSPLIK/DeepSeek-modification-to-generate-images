import os
import json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, colorchooser
from PIL import Image, ImageDraw

# ---------- Глобальные константы ----------
BASE_CELL_SIZE = 20
SAVED_COLORS_FILE = "saved_colors.json"
ZOOM_LEVELS = [0.25, 0.5, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0]

def create_transparent_bg(size):
    img = Image.new("RGBA", (size, size), (255, 255, 255, 255))
    draw = ImageDraw.Draw(img)
    sq = size // 8
    for y in range(8):
        for x in range(8):
            if (x + y) % 2 == 0:
                draw.rectangle([x*sq, y*sq, (x+1)*sq, (y+1)*sq], fill=(220, 220, 220))
    return img

def point_in_triangle(pt, v1, v2, v3):
    x, y = pt
    x1, y1 = v1
    x2, y2 = v2
    x3, y3 = v3
    denom = ((y2 - y3)*(x1 - x3) + (x3 - x2)*(y1 - y3))
    if denom == 0:
        return False
    a = ((y2 - y3)*(x - x3) + (x3 - x2)*(y - y3)) / denom
    b = ((y3 - y1)*(x - x3) + (x1 - x3)*(y - y3)) / denom
    c = 1 - a - b
    return a >= 0 and b >= 0 and c >= 0

# ---------- Стартовое окно ----------
class StartWindow(tk.Toplevel):
    def __init__(self, master, callback):
        super().__init__(master)
        self.title("Новый холст")
        self.callback = callback
        self.selected_file = None
        self.file_data = None
        self.resizable(False, False)
        self.configure(bg='#2d2d2d')

        frame_res = ttk.LabelFrame(self, text="Разрешение холста")
        frame_res.pack(padx=10, pady=5, fill="x")
        ttk.Label(frame_res, text="Ширина:").grid(row=0, column=0, sticky="e", padx=5, pady=2)
        self.w_entry = ttk.Entry(frame_res, width=5)
        self.w_entry.grid(row=0, column=1, padx=5, pady=2)
        self.w_entry.insert(0, "32")  # значение по умолчанию
        ttk.Label(frame_res, text="Высота:").grid(row=1, column=0, sticky="e", padx=5, pady=2)
        self.h_entry = ttk.Entry(frame_res, width=5)
        self.h_entry.grid(row=1, column=1, padx=5, pady=2)
        self.h_entry.insert(0, "32")  # значение по умолчанию

        frame_files = ttk.LabelFrame(self, text="Сохранённые файлы (.pixartimage)")
        frame_files.pack(padx=10, pady=5, fill="both", expand=True)
        self.file_listbox = tk.Listbox(frame_files, height=6, bg='#3c3c3c', fg='white', selectbackground='#5a5a5a')
        self.file_listbox.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(frame_files, orient="vertical", command=self.file_listbox.yview)
        scrollbar.pack(side="right", fill="y")
        self.file_listbox.config(yscrollcommand=scrollbar.set)

        self.btn_continue = ttk.Button(self, text="Продолжить", command=self.on_continue)
        self.btn_continue.pack(pady=10)

        self.scan_files()
        self.file_listbox.bind('<<ListboxSelect>>', self.on_file_select)
        self.w_entry.bind('<KeyRelease>', self.check_state)
        self.h_entry.bind('<KeyRelease>', self.check_state)

        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.grab_set()

    def scan_files(self):
        self.file_listbox.delete(0, "end")
        script_dir = os.path.dirname(os.path.abspath(__file__))
        for f in os.listdir(script_dir):
            if f.endswith('.pixartimage'):
                self.file_listbox.insert("end", f)

    def on_file_select(self, event):
        selection = self.file_listbox.curselection()
        if selection:
            filename = self.file_listbox.get(selection[0])
            script_dir = os.path.dirname(os.path.abspath(__file__))
            filepath = os.path.join(script_dir, filename)
            try:
                with open(filepath, 'r', encoding='utf-8') as file:
                    content = file.read()
                decoder = json.JSONDecoder()
                data, end_pos = decoder.raw_decode(content)
                if 'w' in data and 'h' in data and 'p' in data:
                    w = data['w']
                    h = data['h']
                    encoded_pixels = data['p']
                    pixels = self.decode_pixels(encoded_pixels, w, h)
                elif 'width' in data and 'height' in data and 'pixels' in data:
                    w = data['width']
                    h = data['height']
                    pixels = data['pixels']
                else:
                    raise ValueError("Неизвестный формат файла")
                self.file_data = {'width': w, 'height': h, 'pixels': pixels}
                self.selected_file = filename
                self.w_entry.config(state='normal')
                self.w_entry.delete(0, "end")
                self.w_entry.insert(0, str(w))
                self.w_entry.config(state='disabled')
                self.h_entry.config(state='normal')
                self.h_entry.delete(0, "end")
                self.h_entry.insert(0, str(h))
                self.h_entry.config(state='disabled')
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось загрузить файл:\n{e}")
                self.file_data = None
                self.selected_file = None
                self.w_entry.config(state='normal')
                self.h_entry.config(state='normal')
        else:
            self.selected_file = None
            self.file_data = None
            self.w_entry.config(state='normal')
            self.h_entry.config(state='normal')

    def check_state(self, event=None):
        if self.selected_file:
            self.btn_continue.config(state="normal")
        else:
            try:
                w = int(self.w_entry.get())
                h = int(self.h_entry.get())
                if w > 0 and h > 0:
                    self.btn_continue.config(state="normal")
                else:
                    self.btn_continue.config(state="disabled")
            except:
                self.btn_continue.config(state="disabled")

    def on_continue(self):
        if self.selected_file and self.file_data:
            w = self.file_data['width']
            h = self.file_data['height']
            pixels = self.file_data['pixels']
            self.callback(w, h, pixels, self.selected_file)
            self.destroy()
        else:
            try:
                w = int(self.w_entry.get())
                h = int(self.h_entry.get())
                if w > 0 and h > 0:
                    self.callback(w, h, None, None)
                    self.destroy()
                else:
                    messagebox.showwarning("Внимание", "Введите положительные числа!")
            except ValueError:
                messagebox.showwarning("Внимание", "Введите корректные числа!")

    def on_close(self):
        self.callback(None, None, None, None)
        self.destroy()

    @staticmethod
    def decode_pixels(encoded, w, h):
        pixels = []
        for row_str in encoded:
            row = []
            for i in range(0, w * 8, 8):
                hex_val = row_str[i:i+8]
                r = int(hex_val[0:2], 16)
                g = int(hex_val[2:4], 16)
                b = int(hex_val[4:6], 16)
                a = int(hex_val[6:8], 16)
                row.append((r, g, b, a))
            pixels.append(row)
        return pixels


# ---------- Главный редактор (остальной код без изменений) ----------
class MainEditor:
    def __init__(self, master, width, height, initial_pixels=None, filename=None):
        self.master = master
        self.master.title("Пиксель-арт редактор")
        self.width = width
        self.height = height
        self.filename = filename
        self.modified = False

        self.tool = "brush"
        self.shape_type = "square"
        self.current_color = (0, 0, 0, 255)
        self.saved_colors = self.load_saved_colors()
        self.selected_saved_index = None
        self.brush_radius = 1

        if initial_pixels:
            self.pixels = [[tuple(p) for p in row] for row in initial_pixels]
        else:
            self.pixels = [[(0, 0, 0, 0) for _ in range(width)] for _ in range(height)]

        self.undo_stack = []
        self.redo_stack = []
        self.current_action = []

        self.drawing_shape = False
        self.shape_start = None
        self.shape_end = None
        self.preview_cells = set()
        self.preview_items = []
        self.last_cell = None

        self.base_scale = 1.0
        self.scale_factor = 1.0
        self.zoom_index = 2
        self.initial_fit = True

        self.setup_theme()
        self.create_widgets()
        
        # Даём окну время на отрисовку перед созданием сетки
        self.master.update_idletasks()
        self.create_grid()

        self.master.attributes('-fullscreen', True)
        self.master.bind('<Escape>', lambda e: self.master.attributes('-fullscreen', False))
        self.master.bind('<Control-z>', lambda e: self.undo())
        self.master.bind('<Control-y>', lambda e: self.redo())
        self.master.protocol("WM_DELETE_WINDOW", self.on_close)

    def setup_theme(self):
        style = ttk.Style()
        style.theme_use('clam')
        bg = '#2d2d2d'
        fg = '#ffffff'
        style.configure('.', background=bg, foreground=fg, fieldbackground='#3c3c3c')
        style.configure('TFrame', background=bg)
        style.configure('TLabel', background=bg)
        style.configure('TButton', background='#4d4d4d', foreground=fg, borderwidth=1)
        style.map('TButton', background=[('active', '#5a5a5a')])
        style.configure('Horizontal.TScale', background=bg)
        style.configure('Vertical.TScrollbar', background=bg)
        style.configure('TLabelframe', background=bg, foreground=fg)
        style.configure('TLabelframe.Label', background=bg, foreground=fg)
        style.configure('TCheckbutton', background=bg, foreground=fg)
        style.map('TCheckbutton', background=[('active', bg)])
        style.configure('TSpinbox', background='#3c3c3c', foreground=fg, fieldbackground='#3c3c3c')
        style.map('TSpinbox', background=[('active', '#5a5a5a')])
        self.master.configure(bg=bg)

    def create_widgets(self):
        left_frame = ttk.Frame(self.master, width=320)
        left_frame.pack(side="left", fill="y", padx=10, pady=10)
        left_frame.pack_propagate(False)

        ttk.Label(left_frame, text="Инструмент:").pack(anchor="w")
        tools_frame = ttk.Frame(left_frame)
        tools_frame.pack(fill="x", pady=5)
        self.btn_eraser = ttk.Button(tools_frame, text="Ластик", command=lambda: self.set_tool("eraser"))
        self.btn_eraser.grid(row=0, column=0, padx=2, pady=2, sticky="ew")
        self.btn_brush = ttk.Button(tools_frame, text="Кисть", command=lambda: self.set_tool("brush"))
        self.btn_brush.grid(row=0, column=1, padx=2, pady=2, sticky="ew")
        self.btn_fill = ttk.Button(tools_frame, text="Заливка", command=lambda: self.set_tool("fill"))
        self.btn_fill.grid(row=0, column=2, padx=2, pady=2, sticky="ew")
        self.btn_shape = ttk.Button(tools_frame, text="Формы", command=lambda: self.set_tool("shape"))
        self.btn_shape.grid(row=1, column=0, padx=2, pady=2, sticky="ew")
        tools_frame.columnconfigure(0, weight=1)
        tools_frame.columnconfigure(1, weight=1)
        tools_frame.columnconfigure(2, weight=1)

        action_frame = ttk.Frame(left_frame)
        action_frame.pack(fill="x", pady=5)
        self.zoom_out_btn = ttk.Button(action_frame, text="−", width=2, command=self.zoom_out)
        self.zoom_out_btn.pack(side="left", padx=2)
        self.zoom_label = ttk.Label(action_frame, text="100%", width=6, anchor="center")
        self.zoom_label.pack(side="left")
        self.zoom_in_btn = ttk.Button(action_frame, text="+", width=2, command=self.zoom_in)
        self.zoom_in_btn.pack(side="left", padx=2)
        self.undo_btn = ttk.Button(action_frame, text="↶", width=3, command=self.undo)
        self.undo_btn.pack(side="left", padx=(10,2))
        self.redo_btn = ttk.Button(action_frame, text="↷", width=3, command=self.redo)
        self.redo_btn.pack(side="left", padx=2)
        self.pipette_btn = ttk.Button(action_frame, text="💧", width=3, command=lambda: self.set_tool("pipette"))
        self.pipette_btn.pack(side="left", padx=(10,2))

        self.params_frame = ttk.Frame(left_frame)
        self.params_frame.pack(fill="both", expand=True, pady=5)

        right_frame = ttk.Frame(self.master)
        right_frame.pack(side="right", fill="both", expand=True)

        canvas_frame = ttk.Frame(right_frame)
        canvas_frame.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(canvas_frame, bg="#2d2d2d", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        self.canvas.bind("<Button-1>", self.on_mouse_down)
        self.canvas.bind("<B1-Motion>", self.on_mouse_move)
        self.canvas.bind("<ButtonRelease-1>", self.on_mouse_up)
        self.canvas.bind("<Button-2>", self.on_pan_start)
        self.canvas.bind("<B2-Motion>", self.on_pan_move)
        self.canvas.bind("<Configure>", self.on_canvas_configure)

        save_frame = ttk.Frame(right_frame)
        save_frame.pack(side="bottom", fill="x", pady=10, padx=10)
        self.save_btn = ttk.Button(save_frame, text="Сохранить", command=self.save, state="disabled")
        self.save_btn.pack(side="left", padx=5)
        self.save_as_btn = ttk.Button(save_frame, text="Сохранить как...", command=self.save_as)
        self.save_as_btn.pack(side="left", padx=5)

        self.update_save_buttons()
        self.show_brush_params()

    # ... (все остальные методы MainEditor остаются теми же, что и в предыдущем ответе)
    # Я опускаю их здесь для краткости, но в полном коде они присутствуют.

    def clear_params(self):
        for widget in self.params_frame.winfo_children():
            widget.destroy()

    def set_tool(self, tool):
        self.tool = tool
        self.clear_params()
        if tool == "eraser":
            self.show_eraser_params()
        elif tool == "brush":
            self.show_brush_params()
        elif tool == "fill":
            self.create_color_block()
        elif tool == "shape":
            self.show_shape_params()
        elif tool == "pipette":
            ttk.Label(self.params_frame, text="Пипетка: кликните по пикселю для выбора цвета.").pack()
        self.drawing_shape = False
        self.clear_preview()

    def show_eraser_params(self):
        thick_frame = ttk.Frame(self.params_frame)
        thick_frame.pack(fill="x", pady=5)
        ttk.Label(thick_frame, text="Толщина (радиус):").pack(anchor="w")
        self.thickness_var = tk.IntVar(value=self.brush_radius)
        thick_inner = ttk.Frame(thick_frame)
        thick_inner.pack(fill="x")
        self.thickness_scale = ttk.Scale(thick_inner, from_=1, to=20, orient="horizontal",
                                         variable=self.thickness_var, command=self.on_thickness_change)
        self.thickness_scale.pack(side="left", fill="x", expand=True)
        self.thickness_spin = ttk.Spinbox(thick_inner, from_=1, to=20, width=4,
                                          textvariable=self.thickness_var, command=self.on_thickness_change)
        self.thickness_spin.pack(side="left", padx=5)
        self.thickness_spin.bind('<Up>', lambda e: self.thickness_var.set(min(20, self.thickness_var.get()+1)))
        self.thickness_spin.bind('<Down>', lambda e: self.thickness_var.set(max(1, self.thickness_var.get()-1)))

    def show_brush_params(self):
        self.create_color_block()
        thick_frame = ttk.Frame(self.params_frame)
        thick_frame.pack(fill="x", pady=5)
        ttk.Label(thick_frame, text="Толщина (радиус):").pack(anchor="w")
        self.thickness_var = tk.IntVar(value=self.brush_radius)
        thick_inner = ttk.Frame(thick_frame)
        thick_inner.pack(fill="x")
        self.thickness_scale = ttk.Scale(thick_inner, from_=1, to=20, orient="horizontal",
                                         variable=self.thickness_var, command=self.on_thickness_change)
        self.thickness_scale.pack(side="left", fill="x", expand=True)
        self.thickness_spin = ttk.Spinbox(thick_inner, from_=1, to=20, width=4,
                                          textvariable=self.thickness_var, command=self.on_thickness_change)
        self.thickness_spin.pack(side="left", padx=5)
        self.thickness_spin.bind('<Up>', lambda e: self.thickness_var.set(min(20, self.thickness_var.get()+1)))
        self.thickness_spin.bind('<Down>', lambda e: self.thickness_var.set(max(1, self.thickness_var.get()-1)))

    def show_shape_params(self):
        shape_choice = ttk.LabelFrame(self.params_frame, text="Форма")
        shape_choice.pack(fill="x", pady=5)
        self.shape_var = tk.StringVar(value="square")
        ttk.Radiobutton(shape_choice, text="Квадрат", variable=self.shape_var, value="square").pack(anchor="w")
        ttk.Radiobutton(shape_choice, text="Круг", variable=self.shape_var, value="circle").pack(anchor="w")
        ttk.Radiobutton(shape_choice, text="Треугольник", variable=self.shape_var, value="triangle").pack(anchor="w")
        self.shape_var.trace_add("write", lambda *a: self.set_shape_type())

        self.fill_var = tk.BooleanVar(value=True)
        self.fill_check = ttk.Checkbutton(self.params_frame, text="Заливка", variable=self.fill_var)
        self.fill_check.pack(anchor="w", pady=5)

        self.create_color_block()

    def set_shape_type(self):
        self.shape_type = self.shape_var.get()

    def on_thickness_change(self, *args):
        self.brush_radius = self.thickness_var.get()

    def create_color_block(self):
        color_frame = ttk.LabelFrame(self.params_frame, text="Цвет")
        color_frame.pack(fill="x", pady=5)

        rgb_frame = ttk.Frame(color_frame)
        rgb_frame.pack(pady=2)
        ttk.Label(rgb_frame, text="R:").grid(row=0, column=0)
        self.r_var = tk.StringVar(value="0")
        self.r_entry = ttk.Entry(rgb_frame, width=4, textvariable=self.r_var)
        self.r_entry.grid(row=0, column=1)
        ttk.Label(rgb_frame, text="G:").grid(row=0, column=2)
        self.g_var = tk.StringVar(value="0")
        self.g_entry = ttk.Entry(rgb_frame, width=4, textvariable=self.g_var)
        self.g_entry.grid(row=0, column=3)
        ttk.Label(rgb_frame, text="B:").grid(row=0, column=4)
        self.b_var = tk.StringVar(value="0")
        self.b_entry = ttk.Entry(rgb_frame, width=4, textvariable=self.b_var)
        self.b_entry.grid(row=0, column=5)
        for var in (self.r_var, self.g_var, self.b_var):
            var.trace_add("write", self.on_color_change)

        hex_frame = ttk.Frame(color_frame)
        hex_frame.pack(pady=2)
        ttk.Label(hex_frame, text="HEX:").pack(side="left")
        self.hex_var = tk.StringVar(value="#000000")
        self.hex_entry = ttk.Entry(hex_frame, width=8, textvariable=self.hex_var)
        self.hex_entry.pack(side="left", padx=5)
        self.hex_var.trace_add("write", self.on_hex_change)

        ttk.Button(color_frame, text="Color Picker", command=self.pick_color).pack(pady=2)

        preview_frame = ttk.LabelFrame(color_frame, text="Превью", width=80, height=40)
        preview_frame.pack(pady=5)
        preview_frame.pack_propagate(False)
        self.color_swatch = tk.Canvas(preview_frame, bg="white", highlightthickness=0)
        self.color_swatch.pack(fill="both", expand=True)

        alpha_frame = ttk.Frame(color_frame)
        alpha_frame.pack(pady=2, fill="x")
        ttk.Label(alpha_frame, text="Прозрачность:").pack(anchor="w")
        alpha_inner = ttk.Frame(alpha_frame)
        alpha_inner.pack(fill="x")
        self.alpha_scale = ttk.Scale(alpha_inner, from_=0, to=255, orient="horizontal",
                                     command=self.on_alpha_change)
        self.alpha_scale.set(255)
        self.alpha_scale.pack(side="left", fill="x", expand=True)
        self.alpha_var = tk.IntVar(value=255)
        self.alpha_spin = ttk.Spinbox(alpha_inner, from_=0, to=255, width=5,
                                      textvariable=self.alpha_var, command=self.on_alpha_spin)
        self.alpha_spin.pack(side="left", padx=5)
        self.alpha_spin.bind('<Up>', lambda e: self.alpha_var.set(min(255, self.alpha_var.get()+1)))
        self.alpha_spin.bind('<Down>', lambda e: self.alpha_var.set(max(0, self.alpha_var.get()-1)))
        self.alpha_var.trace_add("write", self.on_alpha_spin)

        saved_frame = ttk.LabelFrame(self.params_frame, text="Сохранённые цвета")
        saved_frame.pack(fill="both", expand=True, pady=5)
        self.saved_canvas = tk.Canvas(saved_frame, height=80, bg="#2d2d2d", highlightthickness=0)
        self.saved_canvas.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(saved_frame, orient="vertical", command=self.saved_canvas.yview)
        scrollbar.pack(side="right", fill="y")
        self.saved_canvas.configure(yscrollcommand=scrollbar.set)
        self.saved_inner_frame = ttk.Frame(self.saved_canvas)
        self.saved_canvas.create_window((0,0), window=self.saved_inner_frame, anchor="nw")
        self.saved_inner_frame.bind("<Configure>", lambda e: self.saved_canvas.configure(scrollregion=self.saved_canvas.bbox("all")))
        self.display_saved_colors()

        btn_frame = ttk.Frame(self.params_frame)
        btn_frame.pack(pady=5)
        self.btn_select_color = ttk.Button(btn_frame, text="Выбрать", command=self.select_saved_color, state="disabled")
        self.btn_select_color.pack(side="left", padx=2)
        self.btn_save_color = ttk.Button(btn_frame, text="Сохранить", command=self.save_current_color)
        self.btn_save_color.pack(side="left", padx=2)
        self.btn_delete_color = ttk.Button(btn_frame, text="Удалить", command=self.delete_saved_color, state="disabled")
        self.btn_delete_color.pack(side="left", padx=2)

        self.update_color_display()

    def on_color_change(self, *args):
        try:
            r = max(0, min(255, int(self.r_var.get())))
            g = max(0, min(255, int(self.g_var.get())))
            b = max(0, min(255, int(self.b_var.get())))
        except:
            return
        self.hex_var.set(f"#{r:02x}{g:02x}{b:02x}")
        self.current_color = (r, g, b, self.current_color[3])
        self.update_color_display()

    def on_hex_change(self, *args):
        hex_str = self.hex_var.get().lstrip('#')
        if len(hex_str) == 6:
            try:
                r = int(hex_str[0:2], 16)
                g = int(hex_str[2:4], 16)
                b = int(hex_str[4:6], 16)
                self.r_var.set(str(r))
                self.g_var.set(str(g))
                self.b_var.set(str(b))
            except:
                pass

    def pick_color(self):
        rgb, hex_str = colorchooser.askcolor(title="Выберите цвет")
        if rgb:
            r, g, b = map(int, rgb)
            self.r_var.set(str(r))
            self.g_var.set(str(g))
            self.b_var.set(str(b))
            self.hex_var.set(hex_str)
            self.current_color = (r, g, b, self.current_color[3])
            self.update_color_display()

    def on_alpha_change(self, value):
        alpha = int(float(value))
        self.alpha_var.set(alpha)
        self.current_color = (self.current_color[0], self.current_color[1], self.current_color[2], alpha)
        self.update_color_display()

    def on_alpha_spin(self, *args):
        try:
            alpha = self.alpha_var.get()
        except:
            return
        self.alpha_scale.set(alpha)
        self.current_color = (self.current_color[0], self.current_color[1], self.current_color[2], alpha)
        self.update_color_display()

    def update_color_display(self):
        r, g, b, a = self.current_color
        self.color_swatch.delete("all")
        w = self.color_swatch.winfo_width() or 80
        h = self.color_swatch.winfo_height() or 40
        sq = 8
        for y in range(0, h, sq):
            for x in range(0, w, sq):
                if (x//sq + y//sq) % 2 == 0:
                    self.color_swatch.create_rectangle(x, y, x+sq, y+sq, fill="#cccccc", outline="")
                else:
                    self.color_swatch.create_rectangle(x, y, x+sq, y+sq, fill="#ffffff", outline="")
        if a > 0:
            hex_color = f"#{r:02x}{g:02x}{b:02x}"
            self.color_swatch.create_rectangle(0, 0, w, h, fill=hex_color, outline="")

    def display_saved_colors(self):
        for widget in self.saved_inner_frame.winfo_children():
            widget.destroy()
        cols = 4
        for i, col in enumerate(self.saved_colors):
            r, g, b, a = col
            hex_col = f"#{r:02x}{g:02x}{b:02x}"
            btn = tk.Button(self.saved_inner_frame, bg=hex_col, width=3, height=1,
                            relief="ridge", command=lambda idx=i: self.on_saved_color_click(idx))
            btn.grid(row=i//cols, column=i%cols, padx=1, pady=1)

    def on_saved_color_click(self, index):
        self.selected_saved_index = index
        self.btn_select_color.config(state="normal")
        self.btn_delete_color.config(state="normal")

    def select_saved_color(self):
        if self.selected_saved_index is not None:
            col = self.saved_colors[self.selected_saved_index]
            self.current_color = col
            self.r_var.set(str(col[0]))
            self.g_var.set(str(col[1]))
            self.b_var.set(str(col[2]))
            self.hex_var.set(f"#{col[0]:02x}{col[1]:02x}{col[2]:02x}")
            self.alpha_scale.set(col[3])
            self.alpha_var.set(col[3])
            self.update_color_display()

    def save_current_color(self):
        self.saved_colors.append(self.current_color)
        self.save_saved_colors()
        self.display_saved_colors()

    def delete_saved_color(self):
        if self.selected_saved_index is not None:
            del self.saved_colors[self.selected_saved_index]
            self.selected_saved_index = None
            self.save_saved_colors()
            self.display_saved_colors()
            self.btn_select_color.config(state="disabled")
            self.btn_delete_color.config(state="disabled")

    def load_saved_colors(self):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(script_dir, SAVED_COLORS_FILE)
        if os.path.exists(path):
            try:
                with open(path, 'r') as f:
                    data = json.load(f)
                    return [tuple(c) for c in data]
            except:
                return []
        return []

    def save_saved_colors(self):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(script_dir, SAVED_COLORS_FILE)
        with open(path, 'w') as f:
            json.dump(self.saved_colors, f)

    def create_grid(self):
        self.canvas.delete("all")
        self.cell_items = {}
        for row in range(self.height):
            for col in range(self.width):
                x1 = col * BASE_CELL_SIZE
                y1 = row * BASE_CELL_SIZE
                x2 = x1 + BASE_CELL_SIZE
                y2 = y1 + BASE_CELL_SIZE
                color = self.get_display_color(row, col)
                item = self.canvas.create_rectangle(
                    x1, y1, x2, y2,
                    fill=color, outline="gray",
                    tags=("cell",)
                )
                self.cell_items[(row, col)] = item
        self.canvas.config(scrollregion=self.canvas.bbox("all"))

    def get_display_color(self, row, col):
        r, g, b, a = self.pixels[row][col]
        if a == 0:
            return "#cccccc"
        else:
            return f"#{r:02x}{g:02x}{b:02x}"

    def update_cell_display(self, row, col):
        if (row, col) in self.cell_items:
            item = self.cell_items[(row, col)]
            color = self.get_display_color(row, col)
            self.canvas.itemconfig(item, fill=color)

    def get_cell(self, event):
        x = self.canvas.canvasx(event.x) / self.scale_factor
        y = self.canvas.canvasy(event.y) / self.scale_factor
        col = int(x // BASE_CELL_SIZE)
        row = int(y // BASE_CELL_SIZE)
        if 0 <= col < self.width and 0 <= row < self.height:
            return col, row
        return None

    def on_canvas_configure(self, event):
        if self.initial_fit:
            self.after(100, self.fit_to_window)  # небольшая задержка для правильного размера
            self.initial_fit = False

    def fit_to_window(self):
        bbox = self.canvas.bbox("all")
        if not bbox:
            return
        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()
        if canvas_w < 10 or canvas_h < 10:
            return
        content_w = bbox[2] - bbox[0]
        content_h = bbox[3] - bbox[1]
        scale = min(canvas_w / content_w, canvas_h / content_h)
        self.canvas.scale("all", 0, 0, scale, scale)
        self.base_scale = scale
        self.scale_factor = self.base_scale * ZOOM_LEVELS[self.zoom_index]
        self.canvas.config(scrollregion=self.canvas.bbox("all"))
        self.center_view()
        self.update_zoom_label()

    def zoom_in(self):
        if self.zoom_index < len(ZOOM_LEVELS)-1:
            self.zoom_index += 1
            self.apply_zoom()

    def zoom_out(self):
        if self.zoom_index > 0:
            self.zoom_index -= 1
            self.apply_zoom()

    def apply_zoom(self):
        target_scale = self.base_scale * ZOOM_LEVELS[self.zoom_index]
        rel_scale = target_scale / self.scale_factor
        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()
        cx = self.canvas.canvasx(canvas_w/2)
        cy = self.canvas.canvasy(canvas_h/2)
        self.canvas.scale("all", cx, cy, rel_scale, rel_scale)
        self.scale_factor = target_scale
        self.canvas.config(scrollregion=self.canvas.bbox("all"))
        self.update_zoom_label()

    def update_zoom_label(self):
        pct = int(ZOOM_LEVELS[self.zoom_index] * 100)
        self.zoom_label.config(text=f"{pct}%")

    def center_view(self):
        self.canvas.update_idletasks()
        bbox = self.canvas.bbox("all")
        if not bbox:
            return
        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()
        if canvas_w < 1 or canvas_h < 1:
            return
        cx = (bbox[0] + bbox[2]) / 2
        cy = (bbox[1] + bbox[3]) / 2
        left = cx - canvas_w / 2
        top = cy - canvas_h / 2
        scroll_region = self.canvas.cget('scrollregion')
        if scroll_region:
            sr = [int(x) for x in scroll_region.split()]
            sr_width = sr[2] - sr[0]
            sr_height = sr[3] - sr[1]
        else:
            return
        if sr_width <= canvas_w:
            frac_x = 0
        else:
            frac_x = left / (sr_width - canvas_w)
        if sr_height <= canvas_h:
            frac_y = 0
        else:
            frac_y = top / (sr_height - canvas_h)
        self.canvas.xview_moveto(max(0, min(frac_x, 1)))
        self.canvas.yview_moveto(max(0, min(frac_y, 1)))

    def on_pan_start(self, event):
        self.canvas.scan_mark(event.x, event.y)

    def on_pan_move(self, event):
        self.canvas.scan_dragto(event.x, event.y, gain=1)

    def on_mouse_down(self, event):
        if self.tool == "pipette":
            cell = self.get_cell(event)
            if cell:
                col, row = cell
                picked = self.pixels[row][col]
                self.current_color = picked
                self.r_var.set(str(picked[0]))
                self.g_var.set(str(picked[1]))
                self.b_var.set(str(picked[2]))
                self.hex_var.set(f"#{picked[0]:02x}{picked[1]:02x}{picked[2]:02x}")
                self.alpha_scale.set(picked[3])
                self.alpha_var.set(picked[3])
                self.update_color_display()
                self.set_tool("brush")
            return

        self.current_action = []
        if self.tool in ("eraser", "brush"):
            cell = self.get_cell(event)
            if cell:
                self.apply_brush_cell(cell)
                self.last_cell = cell
        elif self.tool == "fill":
            cell = self.get_cell(event)
            if cell:
                self.flood_fill(cell[0], cell[1])
        elif self.tool == "shape":
            cell = self.get_cell(event)
            if cell:
                self.drawing_shape = True
                self.shape_start = cell
                self.shape_end = cell
                self.update_preview_cells()
                self.draw_preview()

    def on_mouse_move(self, event):
        if self.drawing_shape:
            cell = self.get_cell(event)
            if cell and cell != self.shape_end:
                self.shape_end = cell
                self.update_preview_cells()
                self.draw_preview()
        elif self.tool in ("eraser", "brush"):
            cell = self.get_cell(event)
            if cell and cell != self.last_cell:
                self.apply_brush_cell(cell)
                self.last_cell = cell

    def on_mouse_up(self, event):
        if self.drawing_shape:
            self.drawing_shape = False
            self.clear_preview()
            if self.shape_start and self.shape_end:
                self.rasterize_shape()
            self.shape_start = None
            self.shape_end = None
        else:
            if self.current_action:
                self.push_undo_action()
        self.last_cell = None

    def apply_brush_cell(self, cell):
        col, row = cell
        rad = self.brush_radius
        action = []
        for dr in range(-rad+1, rad):
            for dc in range(-rad+1, rad):
                r = row + dr
                c = col + dc
                if 0 <= r < self.height and 0 <= c < self.width:
                    old = self.pixels[r][c]
                    new = (0,0,0,0) if self.tool == "eraser" else self.current_color
                    if old != new:
                        self.pixels[r][c] = new
                        action.append((r, c, old, new))
                        self.update_cell_display(r, c)
        if action:
            self.current_action.extend(action)
            self.modified = True

    def flood_fill(self, col, row):
        target = self.pixels[row][col]
        replacement = self.current_color
        if target == replacement:
            return
        stack = [(row, col)]
        visited = set()
        action = []
        while stack:
            r, c = stack.pop()
            if (r, c) in visited:
                continue
            if 0 <= r < self.height and 0 <= c < self.width and self.pixels[r][c] == target:
                self.pixels[r][c] = replacement
                self.update_cell_display(r, c)
                action.append((r, c, target, replacement))
                visited.add((r, c))
                stack.extend([(r-1,c), (r+1,c), (r,c-1), (r,c+1)])
        if action:
            self.current_action = action
            self.push_undo_action()
            self.modified = True

    def update_preview_cells(self):
        if not self.shape_start or not self.shape_end:
            self.preview_cells = set()
            return
        c1, r1 = self.shape_start
        c2, r2 = self.shape_end
        min_c, max_c = min(c1, c2), max(c1, c2)
        min_r, max_r = min(r1, r2), max(r1, r2)
        shape = self.shape_type

        inside = set()
        for row in range(min_r, max_r + 1):
            for col in range(min_c, max_c + 1):
                cx = col * BASE_CELL_SIZE + BASE_CELL_SIZE//2
                cy = row * BASE_CELL_SIZE + BASE_CELL_SIZE//2
                if shape == "square":
                    inside.add((row, col))
                elif shape == "circle":
                    a = (max_c - min_c + 1) * BASE_CELL_SIZE / 2.0
                    b = (max_r - min_r + 1) * BASE_CELL_SIZE / 2.0
                    center_x = (min_c + max_c + 1) * BASE_CELL_SIZE / 2.0
                    center_y = (min_r + max_r + 1) * BASE_CELL_SIZE / 2.0
                    dx = (cx - center_x) / a
                    dy = (cy - center_y) / b
                    if (dx*dx + dy*dy) <= 1.0:
                        inside.add((row, col))
                elif shape == "triangle":
                    v1 = (min_c * BASE_CELL_SIZE, min_r * BASE_CELL_SIZE)
                    v2 = ((max_c + 1) * BASE_CELL_SIZE, min_r * BASE_CELL_SIZE)
                    v3 = ((max_c + 1) * BASE_CELL_SIZE, (max_r + 1) * BASE_CELL_SIZE)
                    if point_in_triangle((cx, cy), v1, v2, v3):
                        inside.add((row, col))

        self.preview_cells = inside if self.fill_var.get() else set()

    def draw_preview(self):
        self.clear_preview()
        for (row, col) in self.preview_cells:
            if 0 <= row < self.height and 0 <= col < self.width:
                x1 = col * BASE_CELL_SIZE * self.scale_factor
                y1 = row * BASE_CELL_SIZE * self.scale_factor
                x2 = x1 + BASE_CELL_SIZE * self.scale_factor
                y2 = y1 + BASE_CELL_SIZE * self.scale_factor
                item = self.canvas.create_rectangle(
                    x1, y1, x2, y2,
                    fill="#66aaff", outline="", stipple="gray50",
                    tags=("preview",)
                )
                self.preview_items.append(item)

    def clear_preview(self):
        for item in self.preview_items:
            self.canvas.delete(item)
        self.preview_items.clear()
        for (row, col) in self.preview_cells:
            if 0 <= row < self.height and 0 <= col < self.width:
                self.update_cell_display(row, col)
        self.preview_cells.clear()

    def rasterize_shape(self):
        self.update_preview_cells()
        cells_to_paint = self.preview_cells
        self.preview_cells = set()
        action = []
        for (row, col) in cells_to_paint:
            if 0 <= row < self.height and 0 <= col < self.width:
                old = self.pixels[row][col]
                if old != self.current_color:
                    self.pixels[row][col] = self.current_color
                    action.append((row, col, old, self.current_color))
                    self.update_cell_display(row, col)
        if action:
            self.current_action = action
            self.push_undo_action()
            self.modified = True

    def push_undo_action(self):
        if self.current_action:
            self.undo_stack.append(self.current_action)
            self.redo_stack.clear()
            self.current_action = []

    def undo(self):
        if not self.undo_stack:
            return
        action = self.undo_stack.pop()
        reversed_action = []
        for (row, col, old_color, new_color) in action:
            if self.pixels[row][col] == new_color:
                self.pixels[row][col] = old_color
                self.update_cell_display(row, col)
                reversed_action.append((row, col, new_color, old_color))
        self.redo_stack.append(reversed_action)
        self.modified = True

    def redo(self):
        if not self.redo_stack:
            return
        action = self.redo_stack.pop()
        redo_reversed = []
        for (row, col, old_color, new_color) in action:
            if self.pixels[row][col] == old_color:
                self.pixels[row][col] = new_color
                self.update_cell_display(row, col)
                redo_reversed.append((row, col, new_color, old_color))
        self.undo_stack.append(redo_reversed)
        self.modified = True

    def update_save_buttons(self):
        if self.filename:
            self.save_btn.config(state="normal")
        else:
            self.save_btn.config(state="disabled")

    def save(self):
        if not self.filename:
            return
        script_dir = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(script_dir, self.filename)
        self.save_to_file(path)
        self.modified = False
        messagebox.showinfo("Сохранено", "Файл сохранён.")

    def save_as(self):
        self.save_art()

    def save_art(self):
        png_path = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG изображение", "*.png"), ("Все файлы", "*.*")],
            initialdir=os.path.expanduser("~/Desktop"),
            title="Сохранить как..."
        )
        if not png_path:
            return False

        img = Image.new('RGBA', (self.width, self.height))
        pixels_img = img.load()
        for y in range(self.height):
            for x in range(self.width):
                pixels_img[x, y] = self.pixels[y][x]
        img.save(png_path)

        script_dir = os.path.dirname(os.path.abspath(__file__))
        base = os.path.splitext(os.path.basename(png_path))[0]
        pixart_path = os.path.join(script_dir, base + ".pixartimage")
        if os.path.exists(pixart_path) and pixart_path != os.path.join(script_dir, self.filename or ""):
            if not messagebox.askyesno("Перезаписать", f"Файл {pixart_path} уже существует. Заменить?"):
                pixart_path = filedialog.asksaveasfilename(
                    defaultextension=".pixartimage",
                    initialdir=script_dir,
                    title="Сохранить .pixartimage"
                )
                if not pixart_path:
                    return False
        self.save_to_file(pixart_path)
        self.filename = os.path.basename(pixart_path)
        self.modified = False
        self.update_save_buttons()
        messagebox.showinfo("Сохранено", f"PNG сохранён как {png_path}\n.pixartimage сохранён как {pixart_path}")
        return True

    def save_to_file(self, path):
        data = {
            "w": self.width,
            "h": self.height,
            "p": self.encode_pixels(self.pixels, self.width, self.height)
        }
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)

    @staticmethod
    def encode_pixels(pixels, w, h):
        encoded = []
        for row in pixels:
            row_str = ''.join(f'{r:02x}{g:02x}{b:02x}{a:02x}' for (r, g, b, a) in row)
            encoded.append(row_str)
        return encoded

    def on_close(self):
        if self.modified:
            dlg = CloseDialog(self.master)
            result = dlg.result
            if result == "save":
                if self.filename:
                    self.save()
                    self.master.destroy()
                else:
                    if self.save_as():
                        self.master.destroy()
            elif result == "discard":
                self.master.destroy()
        else:
            self.master.destroy()


class CloseDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Несохранённые изменения")
        self.result = "cancel"
        self.configure(bg="#2d2d2d")
        ttk.Label(self, text="У вас есть несохранённые изменения. Что сделать?").pack(pady=10)
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=5)
        ttk.Button(btn_frame, text="Сохранить и выйти", command=lambda: self.set_result("save")).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Выйти без сохранения", command=lambda: self.set_result("discard")).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Отмена", command=lambda: self.set_result("cancel")).pack(side="left", padx=5)
        self.protocol("WM_DELETE_WINDOW", lambda: self.set_result("cancel"))
        self.grab_set()
        self.wait_window()

    def set_result(self, value):
        self.result = value
        self.destroy()


# ---------- Главный запуск ----------
class App:
    def __init__(self, master):
        self.master = master
        self.master.withdraw()
        self.show_start()

    def show_start(self):
        start = StartWindow(self.master, self.start_callback)
        self.master.wait_window(start)

    def start_callback(self, width, height, pixels, filename):
        if width and height:
            self.master.deiconify()
            MainEditor(self.master, width, height, pixels, filename)
        else:
            self.master.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
