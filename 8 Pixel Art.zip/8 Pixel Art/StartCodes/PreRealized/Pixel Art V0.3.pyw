import os
import json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, colorchooser
from PIL import Image

# ---------- Глобальные константы ----------
BASE_CELL_SIZE = 20                # базовый размер ячейки (в системе координат Canvas)
SAVED_COLORS_FILE = "saved_colors.json"

# ---------- Вспомогательные функции ----------
def point_in_triangle(pt, v1, v2, v3):
    """Проверка, лежит ли точка pt внутри треугольника (v1,v2,v3) через барицентрические координаты."""
    x, y = pt
    x1, y1 = v1
    x2, y2 = v2
    x3, y3 = v3
    denom = ((y2 - y3)*(x1 - x3) + (x3 - x2)*(y1 - y3))
    if denom == 0:
        return False
    a = ((y2 - y3)*(x - x3) + (x3 - x2)*(y - y3)) / denom
    b = ((y3 - y1)*(x - x3) + (x1 - x3)*(y - y3)) / denom
    c = 1 - a - b
    return a >= 0 and b >= 0 and c >= 0

# ---------- Стартовое окно ----------
class StartWindow(tk.Toplevel):
    def __init__(self, master, callback):
        super().__init__(master)
        self.title("Новый холст")
        self.callback = callback
        self.selected_file = None
        self.file_data = None
        self.resizable(False, False)

        frame_res = ttk.LabelFrame(self, text="Разрешение холста")
        frame_res.pack(padx=10, pady=5, fill="x")
        ttk.Label(frame_res, text="Ширина:").grid(row=0, column=0, sticky="e", padx=5, pady=2)
        self.w_entry = ttk.Entry(frame_res, width=5)
        self.w_entry.grid(row=0, column=1, padx=5, pady=2)
        ttk.Label(frame_res, text="Высота:").grid(row=1, column=0, sticky="e", padx=5, pady=2)
        self.h_entry = ttk.Entry(frame_res, width=5)
        self.h_entry.grid(row=1, column=1, padx=5, pady=2)

        frame_files = ttk.LabelFrame(self, text="Сохранённые файлы (.pixartimage)")
        frame_files.pack(padx=10, pady=5, fill="both", expand=True)
        self.file_listbox = tk.Listbox(frame_files, height=6)
        self.file_listbox.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(frame_files, orient="vertical", command=self.file_listbox.yview)
        scrollbar.pack(side="right", fill="y")
        self.file_listbox.config(yscrollcommand=scrollbar.set)

        self.btn_continue = ttk.Button(self, text="Продолжить", state="disabled", command=self.on_continue)
        self.btn_continue.pack(pady=10)

        self.scan_files()
        self.file_listbox.bind('<<ListboxSelect>>', self.on_file_select)
        self.w_entry.bind('<KeyRelease>', self.check_state)
        self.h_entry.bind('<KeyRelease>', self.check_state)

        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.grab_set()

    def scan_files(self):
        self.file_listbox.delete(0, "end")
        for f in os.listdir('.'):
            if f.endswith('.pixartimage'):
                self.file_listbox.insert("end", f)

    def on_file_select(self, event):
        selection = self.file_listbox.curselection()
        if selection:
            filename = self.file_listbox.get(selection[0])
            try:
                with open(filename, 'r', encoding='utf-8') as file:
                    data = json.load(file)
                    w = data['width']
                    h = data['height']
                    self.file_data = data
                    self.selected_file = filename
                    self.w_entry.config(state='normal')
                    self.w_entry.delete(0, "end")
                    self.w_entry.insert(0, str(w))
                    self.w_entry.config(state='disabled')
                    self.h_entry.config(state='normal')
                    self.h_entry.delete(0, "end")
                    self.h_entry.insert(0, str(h))
                    self.h_entry.config(state='disabled')
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось загрузить файл:\n{e}")
                self.file_data = None
                self.selected_file = None
                self.w_entry.config(state='normal')
                self.h_entry.config(state='normal')
        else:
            self.selected_file = None
            self.file_data = None
            self.w_entry.config(state='normal')
            self.h_entry.config(state='normal')
        self.check_state()

    def check_state(self, event=None):
        if self.selected_file:
            self.btn_continue.config(state="normal")
        else:
            try:
                w = int(self.w_entry.get())
                h = int(self.h_entry.get())
                if w > 0 and h > 0:
                    self.btn_continue.config(state="normal")
                else:
                    self.btn_continue.config(state="disabled")
            except:
                self.btn_continue.config(state="disabled")

    def on_continue(self):
        if self.selected_file and self.file_data:
            w = self.file_data['width']
            h = self.file_data['height']
            pixels = self.file_data['pixels']
            self.callback(w, h, pixels, self.selected_file)
            self.destroy()
        else:
            try:
                w = int(self.w_entry.get())
                h = int(self.h_entry.get())
                if w > 0 and h > 0:
                    self.callback(w, h, None, None)
                    self.destroy()
            except:
                messagebox.showwarning("Внимание", "Введите корректные размеры или выберите файл.")

    def on_close(self):
        self.callback(None, None, None, None)
        self.destroy()

# ---------- Главный редактор ----------
class MainEditor:
    def __init__(self, master, width, height, initial_pixels=None, filename=None):
        self.master = master
        self.master.title("Пиксель-арт редактор")
        self.width = width
        self.height = height
        self.filename = filename
        self.modified = False

        self.tool = "brush"
        self.shape_type = "square"
        self.current_color = (0, 0, 0, 255)
        self.saved_colors = self.load_saved_colors()
        self.selected_saved_index = None

        if initial_pixels:
            self.pixels = [[tuple(p) for p in row] for row in initial_pixels]
        else:
            self.pixels = [[(0, 0, 0, 0) for _ in range(width)] for _ in range(height)]

        self.drawing_shape = False
        self.shape_start = None
        self.shape_end = None
        self.preview_items = []
        self.last_cell = None

        self.scale_factor = 1.0
        self.initial_fit = True

        self.create_widgets()
        self.create_grid()

        # Полноэкранный режим
        self.master.attributes('-fullscreen', True)
        self.master.bind('<Escape>', lambda e: self.master.attributes('-fullscreen', False))

        self.master.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------- Интерфейс ----------
    def create_widgets(self):
        left_frame = ttk.Frame(self.master, width=250)
        left_frame.pack(side="left", fill="y", padx=5, pady=5)
        left_frame.pack_propagate(False)

        ttk.Label(left_frame, text="Инструмент:").pack(anchor="w")
        tools_frame = ttk.Frame(left_frame)
        tools_frame.pack(fill="x", pady=5)
        self.btn_eraser = ttk.Button(tools_frame, text="Ластик", command=lambda: self.set_tool("eraser"))
        self.btn_eraser.pack(side="left", padx=2)
        self.btn_brush = ttk.Button(tools_frame, text="Кисть", command=lambda: self.set_tool("brush"))
        self.btn_brush.pack(side="left", padx=2)
        self.btn_shape = ttk.Button(tools_frame, text="Формы", command=lambda: self.set_tool("shape"))
        self.btn_shape.pack(side="left", padx=2)

        self.params_frame = ttk.Frame(left_frame)
        self.params_frame.pack(fill="both", expand=True, pady=5)

        right_frame = ttk.Frame(self.master)
        right_frame.pack(side="right", fill="both", expand=True)

        canvas_frame = ttk.Frame(right_frame)
        canvas_frame.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(canvas_frame, bg="#cccccc", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        self.canvas.bind("<Button-1>", self.on_mouse_down)
        self.canvas.bind("<B1-Motion>", self.on_mouse_move)
        self.canvas.bind("<ButtonRelease-1>", self.on_mouse_up)
        self.canvas.bind("<MouseWheel>", self.on_mousewheel)
        self.canvas.bind("<Button-4>", self.on_mousewheel)
        self.canvas.bind("<Button-5>", self.on_mousewheel)
        self.canvas.bind("<Button-2>", self.on_pan_start)
        self.canvas.bind("<B2-Motion>", self.on_pan_move)
        self.canvas.bind("<ButtonRelease-2>", self.on_pan_stop)
        self.canvas.bind("<Configure>", self.on_canvas_configure)

        self.btn_save = ttk.Button(right_frame, text="Сохранить арт", command=self.save_art)
        self.btn_save.pack(pady=10)

        self.show_brush_params()

    def clear_params(self):
        for widget in self.params_frame.winfo_children():
            widget.destroy()

    def set_tool(self, tool):
        self.tool = tool
        self.clear_params()
        if tool == "eraser":
            ttk.Label(self.params_frame, text="Ластик стирает пиксели.").pack()
        elif tool == "brush":
            self.show_brush_params()
        elif tool == "shape":
            self.show_shape_params()
        self.drawing_shape = False

    # ---------- Параметры кисти ----------
    def show_brush_params(self):
        color_frame = ttk.LabelFrame(self.params_frame, text="Цвет")
        color_frame.pack(fill="x", pady=5)

        rgb_frame = ttk.Frame(color_frame)
        rgb_frame.pack(pady=2)
        ttk.Label(rgb_frame, text="R:").grid(row=0, column=0)
        self.r_var = tk.StringVar(value="0")
        self.r_entry = ttk.Entry(rgb_frame, width=4, textvariable=self.r_var)
        self.r_entry.grid(row=0, column=1)
        ttk.Label(rgb_frame, text="G:").grid(row=0, column=2)
        self.g_var = tk.StringVar(value="0")
        self.g_entry = ttk.Entry(rgb_frame, width=4, textvariable=self.g_var)
        self.g_entry.grid(row=0, column=3)
        ttk.Label(rgb_frame, text="B:").grid(row=0, column=4)
        self.b_var = tk.StringVar(value="0")
        self.b_entry = ttk.Entry(rgb_frame, width=4, textvariable=self.b_var)
        self.b_entry.grid(row=0, column=5)
        for var in (self.r_var, self.g_var, self.b_var):
            var.trace_add("write", self.on_color_change)

        hex_frame = ttk.Frame(color_frame)
        hex_frame.pack(pady=2)
        ttk.Label(hex_frame, text="HEX:").pack(side="left")
        self.hex_var = tk.StringVar(value="#000000")
        self.hex_entry = ttk.Entry(hex_frame, width=8, textvariable=self.hex_var)
        self.hex_entry.pack(side="left", padx=5)
        self.hex_var.trace_add("write", self.on_hex_change)

        ttk.Button(color_frame, text="Color Picker", command=self.pick_color).pack(pady=2)

        alpha_frame = ttk.Frame(color_frame)
        alpha_frame.pack(pady=2)
        ttk.Label(alpha_frame, text="Прозрачность (альфа):").pack(anchor="w")
        self.alpha_scale = ttk.Scale(alpha_frame, from_=0, to=255, orient="horizontal", command=self.on_alpha_change)
        self.alpha_scale.set(255)
        self.alpha_scale.pack(fill="x", padx=5)

        self.color_swatch = tk.Canvas(color_frame, width=50, height=20, bg="white")
        self.color_swatch.pack(pady=5)

        saved_frame = ttk.LabelFrame(self.params_frame, text="Сохранённые цвета")
        saved_frame.pack(fill="x", pady=5)
        self.saved_canvas_frame = ttk.Frame(saved_frame)
        self.saved_canvas_frame.pack()
        self.display_saved_colors()

        btn_frame = ttk.Frame(self.params_frame)
        btn_frame.pack(pady=5)
        self.btn_select_color = tk.Button(btn_frame, text="Выбрать цвет", bg="grey", state="disabled",
                                          command=self.select_saved_color)
        self.btn_select_color.pack(side="left", padx=2)
        self.btn_save_color = tk.Button(btn_frame, text="Сохранить цвет", bg="grey", state="disabled",
                                        command=self.save_current_color)
        self.btn_save_color.pack(side="left", padx=2)
        self.btn_delete_color = tk.Button(btn_frame, text="Удалить цвет", bg="grey", state="disabled",
                                          command=self.delete_saved_color)
        self.btn_delete_color.pack(side="left", padx=2)

        self.update_color_display()

    # ---------- Параметры фигур ----------
    def show_shape_params(self):
        shape_choice = ttk.LabelFrame(self.params_frame, text="Форма")
        shape_choice.pack(fill="x", pady=5)
        self.shape_var = tk.StringVar(value="square")
        ttk.Radiobutton(shape_choice, text="Квадрат", variable=self.shape_var, value="square").pack(anchor="w")
        ttk.Radiobutton(shape_choice, text="Круг", variable=self.shape_var, value="circle").pack(anchor="w")
        ttk.Radiobutton(shape_choice, text="Треугольник", variable=self.shape_var, value="triangle").pack(anchor="w")
        self.shape_var.trace_add("write", lambda *a: self.set_shape_type())
        self.show_brush_params()

    def set_shape_type(self):
        self.shape_type = self.shape_var.get()

    # ---------- Логика цвета ----------
    def on_color_change(self, *args):
        try:
            r = max(0, min(255, int(self.r_var.get())))
            g = max(0, min(255, int(self.g_var.get())))
            b = max(0, min(255, int(self.b_var.get())))
        except:
            return
        self.hex_var.set(f"#{r:02x}{g:02x}{b:02x}")
        self.current_color = (r, g, b, self.current_color[3])
        self.update_color_display()

    def on_hex_change(self, *args):
        hex_str = self.hex_var.get().lstrip('#')
        if len(hex_str) == 6:
            try:
                r = int(hex_str[0:2], 16)
                g = int(hex_str[2:4], 16)
                b = int(hex_str[4:6], 16)
                self.r_var.set(str(r))
                self.g_var.set(str(g))
                self.b_var.set(str(b))
            except:
                pass

    def pick_color(self):
        rgb, hex_str = colorchooser.askcolor(title="Выберите цвет")
        if rgb:
            r, g, b = map(int, rgb)
            self.r_var.set(str(r))
            self.g_var.set(str(g))
            self.b_var.set(str(b))
            self.hex_var.set(hex_str)
            self.current_color = (r, g, b, self.current_color[3])
            self.update_color_display()

    def on_alpha_change(self, value):
        self.current_color = (self.current_color[0], self.current_color[1], self.current_color[2], int(float(value)))
        self.update_color_display()

    def update_color_display(self):
        r, g, b, a = self.current_color
        color_hex = f"#{r:02x}{g:02x}{b:02x}"
        self.color_swatch.delete("all")
        self.color_swatch.create_rectangle(0, 0, 50, 20, fill=color_hex, outline="")
        self.color_swatch.create_text(25, 10, text=f"α={a}", fill="white" if (r+g+b)/3 < 128 else "black")

    # ---------- Сохранённые цвета ----------
    def display_saved_colors(self):
        for widget in self.saved_canvas_frame.winfo_children():
            widget.destroy()
        for i, col in enumerate(self.saved_colors):
            r, g, b, a = col
            hex_col = f"#{r:02x}{g:02x}{b:02x}"
            btn = tk.Button(self.saved_canvas_frame, bg=hex_col, width=4, height=2,
                            relief="ridge", command=lambda idx=i: self.on_saved_color_click(idx))
            btn.grid(row=i//8, column=i%8, padx=1, pady=1)

    def on_saved_color_click(self, index):
        self.selected_saved_index = index
        self.btn_select_color.config(state="normal", bg="green")
        self.btn_save_color.config(state="normal", bg="purple")
        self.btn_delete_color.config(state="normal", bg="red")

    def select_saved_color(self):
        if self.selected_saved_index is not None:
            col = self.saved_colors[self.selected_saved_index]
            self.current_color = col
            self.r_var.set(str(col[0]))
            self.g_var.set(str(col[1]))
            self.b_var.set(str(col[2]))
            self.hex_var.set(f"#{col[0]:02x}{col[1]:02x}{col[2]:02x}")
            self.alpha_scale.set(col[3])
            self.update_color_display()

    def save_current_color(self):
        self.saved_colors.append(self.current_color)
        self.save_saved_colors()
        self.display_saved_colors()

    def delete_saved_color(self):
        if self.selected_saved_index is not None:
            del self.saved_colors[self.selected_saved_index]
            self.selected_saved_index = None
            self.save_saved_colors()
            self.display_saved_colors()
            self.btn_select_color.config(state="disabled", bg="grey")
            self.btn_save_color.config(state="disabled", bg="grey")
            self.btn_delete_color.config(state="disabled", bg="grey")

    def load_saved_colors(self):
        if os.path.exists(SAVED_COLORS_FILE):
            try:
                with open(SAVED_COLORS_FILE, 'r') as f:
                    data = json.load(f)
                    return [tuple(c) for c in data]
            except:
                return []
        return []

    def save_saved_colors(self):
        with open(SAVED_COLORS_FILE, 'w') as f:
            json.dump(self.saved_colors, f)

    # ---------- Холст ----------
    def create_grid(self):
        self.canvas.delete("all")
        self.cell_items = {}
        for row in range(self.height):
            for col in range(self.width):
                x1 = col * BASE_CELL_SIZE
                y1 = row * BASE_CELL_SIZE
                x2 = x1 + BASE_CELL_SIZE
                y2 = y1 + BASE_CELL_SIZE
                color = self.get_display_color(row, col)
                item = self.canvas.create_rectangle(
                    x1, y1, x2, y2,
                    fill=color, outline="gray",
                    tags=("cell",)
                )
                self.cell_items[(row, col)] = item
        self.canvas.config(scrollregion=self.canvas.bbox("all"))

    def get_display_color(self, row, col):
        r, g, b, a = self.pixels[row][col]
        if a == 0:
            return "#cccccc"
        else:
            return f"#{r:02x}{g:02x}{b:02x}"

    def update_cell_display(self, row, col):
        item = self.cell_items[(row, col)]
        color = self.get_display_color(row, col)
        self.canvas.itemconfig(item, fill=color)

    def on_canvas_configure(self, event):
        if self.initial_fit:
            self.fit_to_window()
            self.initial_fit = False

    def fit_to_window(self):
        bbox = self.canvas.bbox("all")
        if not bbox:
            return
        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()
        if canvas_w < 10 or canvas_h < 10:
            return
        content_w = bbox[2] - bbox[0]
        content_h = bbox[3] - bbox[1]
        scale_w = canvas_w / content_w
        scale_h = canvas_h / content_h
        scale = min(scale_w, scale_h)
        # Масштабируем содержимое относительно левого верхнего угла
        self.canvas.scale("all", 0, 0, scale, scale)
        self.scale_factor = scale
        self.canvas.config(scrollregion=self.canvas.bbox("all"))
        self.center_view()

    def center_view(self):
        """Центрирует холст по области просмотра."""
        self.canvas.update_idletasks()
        bbox = self.canvas.bbox("all")
        if not bbox:
            return
        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()
        if canvas_w < 1 or canvas_h < 1:
            return
        # Центр bounding box
        cx = (bbox[0] + bbox[2]) / 2
        cy = (bbox[1] + bbox[3]) / 2
        # Желаемое смещение, чтобы центр bounding box оказался в центре Canvas
        left = cx - canvas_w / 2
        top = cy - canvas_h / 2

        scroll_region = self.canvas.cget('scrollregion')
        if scroll_region:
            sr = [int(x) for x in scroll_region.split()]
            sr_width = sr[2] - sr[0]
            sr_height = sr[3] - sr[1]
        else:
            sr_width = bbox[2] - bbox[0]
            sr_height = bbox[3] - bbox[1]

        if sr_width <= canvas_w:
            frac_x = 0
        else:
            frac_x = left / (sr_width - canvas_w)
        if sr_height <= canvas_h:
            frac_y = 0
        else:
            frac_y = top / (sr_height - canvas_h)

        self.canvas.xview_moveto(max(0, min(frac_x, 1)))
        self.canvas.yview_moveto(max(0, min(frac_y, 1)))

    def get_cell(self, event):
        """Возвращает (col, row) по координатам мыши с учётом масштаба и панорамирования."""
        # canvasx/canvasy возвращают координаты в увеличенной системе,
        # поэтому делим на текущий масштаб, чтобы получить базовые координаты.
        x = self.canvas.canvasx(event.x) / self.scale_factor
        y = self.canvas.canvasy(event.y) / self.scale_factor
        col = int(x // BASE_CELL_SIZE)
        row = int(y // BASE_CELL_SIZE)
        if 0 <= col < self.width and 0 <= row < self.height:
            return col, row
        return None

    # ---------- Рисование ----------
    def on_mouse_down(self, event):
        if self.tool in ("eraser", "brush"):
            cell = self.get_cell(event)
            if cell:
                self.apply_tool(cell)
                self.last_cell = cell
        elif self.tool == "shape":
            cell = self.get_cell(event)
            if cell:
                self.drawing_shape = True
                self.shape_start = cell
                self.shape_end = cell
                self.draw_preview()

    def on_mouse_move(self, event):
        if self.drawing_shape:
            cell = self.get_cell(event)
            if cell:
                self.shape_end = cell
                self.draw_preview()
        elif self.tool in ("eraser", "brush"):
            cell = self.get_cell(event)
            if cell and cell != self.last_cell:
                self.apply_tool(cell)
                self.last_cell = cell

    def on_mouse_up(self, event):
        if self.drawing_shape:
            self.drawing_shape = False
            self.clear_preview()
            if self.shape_start and self.shape_end:
                self.rasterize_shape(self.shape_start, self.shape_end)
            self.shape_start = None
            self.shape_end = None
        self.last_cell = None

    def apply_tool(self, cell):
        col, row = cell
        if self.tool == "eraser":
            self.pixels[row][col] = (0, 0, 0, 0)
        elif self.tool == "brush":
            self.pixels[row][col] = self.current_color
        self.modified = True
        self.update_cell_display(row, col)

    def draw_preview(self):
        self.clear_preview()
        if not self.shape_start or not self.shape_end:
            return
        c1, r1 = self.shape_start
        c2, r2 = self.shape_end
        x1 = min(c1, c2) * BASE_CELL_SIZE
        y1 = min(r1, r2) * BASE_CELL_SIZE
        x2 = (max(c1, c2) + 1) * BASE_CELL_SIZE
        y2 = (max(r1, r2) + 1) * BASE_CELL_SIZE

        outline_color = "red"
        tags = ("preview",)
        if self.shape_type == "square":
            item = self.canvas.create_rectangle(x1, y1, x2, y2, outline=outline_color, dash=(3,), tags=tags)
        elif self.shape_type == "circle":
            item = self.canvas.create_oval(x1, y1, x2, y2, outline=outline_color, dash=(3,), tags=tags)
        elif self.shape_type == "triangle":
            points = [x1, y1, x2, y1, x2, y2]
            item = self.canvas.create_polygon(points, outline=outline_color, fill='', dash=(3,), tags=tags)
        self.preview_items.append(item)

    def clear_preview(self):
        for item in self.preview_items:
            self.canvas.delete(item)
        self.preview_items.clear()

    def rasterize_shape(self, start_cell, end_cell):
        c1, r1 = start_cell
        c2, r2 = end_cell
        min_c, max_c = min(c1, c2), max(c1, c2)
        min_r, max_r = min(r1, r2), max(r1, r2)
        shape = self.shape_type

        for row in range(min_r, max_r + 1):
            for col in range(min_c, max_c + 1):
                cx = col * BASE_CELL_SIZE + BASE_CELL_SIZE//2
                cy = row * BASE_CELL_SIZE + BASE_CELL_SIZE//2
                inside = False
                if shape == "square":
                    inside = True
                elif shape == "circle":
                    a = (max_c - min_c + 1) * BASE_CELL_SIZE / 2.0
                    b = (max_r - min_r + 1) * BASE_CELL_SIZE / 2.0
                    center_x = (min_c + max_c + 1) * BASE_CELL_SIZE / 2.0
                    center_y = (min_r + max_r + 1) * BASE_CELL_SIZE / 2.0
                    dx = (cx - center_x) / a
                    dy = (cy - center_y) / b
                    inside = (dx*dx + dy*dy) <= 1.0
                elif shape == "triangle":
                    v1 = (min_c * BASE_CELL_SIZE, min_r * BASE_CELL_SIZE)
                    v2 = ((max_c + 1) * BASE_CELL_SIZE, min_r * BASE_CELL_SIZE)
                    v3 = ((max_c + 1) * BASE_CELL_SIZE, (max_r + 1) * BASE_CELL_SIZE)
                    inside = point_in_triangle((cx, cy), v1, v2, v3)
                if inside:
                    self.pixels[row][col] = self.current_color
                    self.update_cell_display(row, col)
        self.modified = True

    # ---------- Зум и панорамирование ----------
    def on_mousewheel(self, event):
        if event.num == 4 or (hasattr(event, 'delta') and event.delta > 0):
            scale = 1.1
        elif event.num == 5 or (hasattr(event, 'delta') and event.delta < 0):
            scale = 0.9
        else:
            return
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        self.canvas.scale("all", x, y, scale, scale)
        self.scale_factor *= scale
        self.canvas.config(scrollregion=self.canvas.bbox("all"))

    def on_pan_start(self, event):
        self.canvas.scan_mark(event.x, event.y)

    def on_pan_move(self, event):
        self.canvas.scan_dragto(event.x, event.y, gain=1)

    def on_pan_stop(self, event):
        pass

    # ---------- Сохранение ----------
    def save_art(self):
        png_path = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG изображение", "*.png")],
            initialdir=os.path.expanduser("~/Desktop"),
            title="Сохранить PNG"
        )
        if not png_path:
            return False

        img = Image.new('RGBA', (self.width, self.height))
        pixels = img.load()
        for y in range(self.height):
            for x in range(self.width):
                pixels[x, y] = self.pixels[y][x]
        img.save(png_path)

        base = os.path.splitext(os.path.basename(png_path))[0]
        pixart_path = os.path.join(os.path.dirname(__file__), base + ".pixartimage")
        if os.path.exists(pixart_path):
            if not messagebox.askyesno("Перезаписать", f"Файл {pixart_path} уже существует. Заменить?"):
                pixart_path = filedialog.asksaveasfilename(
                    defaultextension=".pixartimage",
                    initialdir=os.path.dirname(__file__),
                    title="Сохранить .pixartimage"
                )
                if not pixart_path:
                    return False
        data = {
            "width": self.width,
            "height": self.height,
            "pixels": self.pixels
        }
        with open(pixart_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)

        self.modified = False
        self.filename = pixart_path
        messagebox.showinfo("Сохранено", f"PNG сохранён на рабочий стол.\n.pixartimage сохранён в папку программы.")
        return True

    # ---------- Закрытие ----------
    def on_close(self):
        if self.modified:
            dlg = CloseDialog(self.master)
            result = dlg.result
            if result == "save":
                if self.save_art():
                    self.master.destroy()
            elif result == "discard":
                self.master.destroy()
        else:
            self.master.destroy()

class CloseDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Несохранённые изменения")
        self.result = "cancel"
        ttk.Label(self, text="У вас есть несохранённые изменения. Что сделать?").pack(pady=10)
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=5)
        ttk.Button(btn_frame, text="Сохранить и выйти", command=lambda: self.set_result("save")).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Выйти без сохранения", command=lambda: self.set_result("discard")).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Отмена", command=lambda: self.set_result("cancel")).pack(side="left", padx=5)
        self.protocol("WM_DELETE_WINDOW", lambda: self.set_result("cancel"))
        self.grab_set()
        self.wait_window()

    def set_result(self, value):
        self.result = value
        self.destroy()

# ---------- Главный запуск ----------
class App:
    def __init__(self, master):
        self.master = master
        self.master.withdraw()
        self.show_start()

    def show_start(self):
        start = StartWindow(self.master, self.start_callback)
        self.master.wait_window(start)

    def start_callback(self, width, height, pixels, filename):
        if width and height:
            self.master.deiconify()
            MainEditor(self.master, width, height, pixels, filename)
        else:
            self.master.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
